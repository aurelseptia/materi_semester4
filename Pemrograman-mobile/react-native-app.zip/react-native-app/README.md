1. git clone https://github.com/Nahrul/react-native-app.git
2. cd react-native-app
3. npm install
4. npm start
